compilertest readme file
